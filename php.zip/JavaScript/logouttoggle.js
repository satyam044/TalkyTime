const logIcon = document.querySelector(".userR i"),
logBtn = document.querySelector(".userR button");

logIcon.addEventListener("click", function(){
    logBtn.classList.toggle("active")
})